# KXP Parts Finder

MVP demonstrativ pentru căutarea pieselor auto.

## GitHub Pages
1. În repository, apasă **Add file → Upload files**.
2. Încarcă `index.html`.
3. Apasă **Commit changes**.
4. Intră la **Settings → Pages**.
5. Selectează **Deploy from a branch**, branch `main`, folder `/root`, apoi Save.

Versiunea actuală folosește date demo. Urmează conectarea Supabase, a unui API de catalog auto și a Stripe.
